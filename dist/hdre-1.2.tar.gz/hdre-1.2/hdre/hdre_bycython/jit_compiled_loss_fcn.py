from numba import jit,njit, prange, types
import numpy as np
